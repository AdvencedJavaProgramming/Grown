package com.Polodz.model;

public interface IDao {

	void addNode(IMember arg);

}
