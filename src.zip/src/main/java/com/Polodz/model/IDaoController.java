package com.Polodz.model;

public interface IDaoController {

}
