package com.Polodz.model;

import java.util.List;

public class NodesDao implements IDao {
	private List<IMember> BscNodes;

	public void addNode(IMember arg) {
		// TODO Auto-generated method stub
	}
}
