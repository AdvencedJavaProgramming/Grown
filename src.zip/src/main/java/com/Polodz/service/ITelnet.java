package com.Polodz.service;

public interface ITelnet {
	public String get(String input);
}
