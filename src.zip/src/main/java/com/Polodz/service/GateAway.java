package com.Polodz.service;

public interface GateAway {
	public String send(String text);
}
