package com.Polodz.controller;

public interface IController {

	public String execute(String string);

}
